from django.apps import AppConfig


class RecipemasterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'RecipeMaster'
